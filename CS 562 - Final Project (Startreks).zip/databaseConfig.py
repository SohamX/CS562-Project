dbconfig = {
    "user": "chinmay",
    "password": "chinmay15",
    "host": "127.0.0.1",
    "port": "5432",
    "database": "sales"
}
